# Architecture

## High-level data flow

```
                     ┌─────────────────────────────────────────────────────────┐
                     │                     Continuous Audit                     │
                     │   (every event below is written to audit_logs + stdout) │
                     └─────────────────────────────────────────────────────────┘
                                          ▲
   ┌──────────┐    ┌──────────┐    ┌─────┴──────┐    ┌────────────┐    ┌───────────────┐
   │ Identity │    │  Device  │    │   Policy   │    │  Decision  │    │ Least-Privilege│
   │ (OIDC /  │───▶│ Posture  │───▶│   Engine   │───▶│ (allow /   │───▶│    Session     │
   │  local)  │    │ (self /  │    │(risk_engine│    │  step_up / │    │ (short-lived   │
   │  + MFA   │    │  EDR)    │    │ + OPA/Rego)│    │  deny)     │    │  JWT, rotating │
   └──────────┘    └──────────┘    └────────────┘    └────────────┘    │  refresh token)│
                                                                        └───────┬────────┘
                                                                                │
                                          Every subsequent sensitive API call  │
                                          re-enters the Policy Engine step     │
                                          (continuous verification), not just  │
                                          at initial login.                    │
                                          ◀───────────────────────────────────┘
```

## Components

| Component  | Technology                | Responsibility |
|------------|---------------------------|----------------|
| Frontend   | Next.js (App Router)      | Login, MFA enrollment, device registration, session/audit views |
| Backend    | FastAPI (async)           | Auth, MFA, device posture, risk scoring, session issuance, policy enforcement point (PEP) |
| Policy Decision Point | OPA (Rego)      | RBAC + ABAC decision, called by the backend via REST for every `policy/check` and continuous-verification event |
| Identity Provider | Keycloak (local demo) | OIDC/OAuth2 Authorization Code + PKCE flow; swap for a real enterprise IdP via `OIDC_ISSUER` |
| Database   | PostgreSQL                | Users, roles, devices, sessions, audit logs |
| Cache      | Redis                     | Reserved for rate limiting / short-lived flow state in a multi-replica deployment (see Known Limitations) |

## Request lifecycle: login

1. Client submits email/password (or completes OIDC redirect) + a device fingerprint.
2. Backend verifies credentials (bcrypt) and, if enrolled, a TOTP MFA code.
3. `risk_engine.py` computes a 0-100 risk score from: MFA status, device posture
   (encryption, screen lock, EDR presence, self-reported vs. verified, trust flag),
   source IP against known ranges, and time-of-day.
4. The score is mapped to `allow` / `step_up` / `deny` using configurable thresholds
   (`RISK_THRESHOLD_ALLOW`, `RISK_THRESHOLD_STEP_UP`, `RISK_THRESHOLD_DENY`).
5. On `allow`/`step_up`, a `Session` row is created and a short-lived (default 10 min)
   JWT access token plus a rotating refresh token (default 24 h) are issued.
6. Every field that fed the decision (risk score, reasons, decision) is written to
   `audit_logs`.

## Request lifecycle: continuous verification

Any protected frontend action or downstream service calls `POST /api/v1/policy/check`
with a `resource`/`action` pair. The backend:

1. Re-derives the caller's current device and MFA state from the live `Session` row
   (not from the JWT alone, so a revoked session cannot bypass this).
2. Recomputes the risk score.
3. Sends `{subject, resource, action, risk_score, device_trusted, mfa_verified}` to OPA's
   `/v1/data/ztp/authz/decision` endpoint, which evaluates RBAC + ABAC + a risk gate
   (see `opa/policy.rego`).
4. Fails **closed**: if OPA is unreachable, the decision is `deny`, not `allow`
   (see `policy_engine.py`).
5. Logs the decision to `audit_logs`, exactly like login.

Refreshing an access token (`POST /api/v1/auth/refresh`) goes through the same risk
re-evaluation, so a session that becomes risky mid-life (e.g. device posture worsens)
is revoked instead of silently renewed.

## Why OPA/Rego is a separate service

Zero Trust as an architectural pattern calls for separating the **Policy Decision
Point** (PDP) from the **Policy Enforcement Point** (PEP). The FastAPI backend is the
PEP: it gathers context (identity, device, risk) and enforces whatever OPA decides, but
does not itself encode authorization rules beyond the risk gate. This means policy can
be changed, tested (`opa/policy_test.rego`), versioned, and audited independently of an
application deployment.

## Data model summary

See `backend/app/models/models.py` for the full SQLAlchemy models. Key tables:
`users`, `roles`, `user_roles` (join table), `devices`, `sessions`, `policy_bundles`
(metadata about which Rego bundle version is active), `audit_logs` (append-only).
