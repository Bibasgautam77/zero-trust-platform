# Threat Model

Scope: this reference implementation, as shipped. Uses a simplified STRIDE pass over
the components in `docs/architecture.md`.

## Assets
- User credentials (password hashes, MFA secrets)
- Session tokens (access + refresh JWTs)
- Device posture data
- Audit log integrity
- Policy definitions (Rego)

## Trust boundaries
1. Browser ↔ Frontend (Next.js) — untrusted network, TLS required in production (not
   configured in this dev docker-compose; see "Production hardening" below).
2. Frontend ↔ Backend (FastAPI) — same as above.
3. Backend ↔ OPA — internal network in docker-compose; should be network-isolated
   (no public port) in production.
4. Backend ↔ Postgres/Redis — internal network; should never be publicly reachable.
5. Backend ↔ external IdP (Keycloak or a real enterprise IdP) — OIDC over TLS in
   production.

## Threats and mitigations

| Threat (STRIDE) | Scenario | Mitigation in this codebase | Residual risk |
|---|---|---|---|
| Spoofing | Credential stuffing / brute force | bcrypt password hashing; MFA (TOTP); risk engine penalizes unknown IP/device | No rate limiting / lockout is implemented yet (see Known Limitations) |
| Spoofing | Device fingerprint forgery | Fingerprint is a client-supplied string, not cryptographically bound to hardware | Documented explicitly: `self_reported=True` unless a real EDR/MDM integration is configured; risk engine treats self-reported posture as weaker evidence |
| Tampering | Refresh token replay | Refresh tokens are single-use (jti rotated on every `/auth/refresh`); reuse of a stale jti is rejected and the session is treated as compromised | Detection triggers rejection but does not yet auto-revoke *other* sessions of the same user (documented improvement) |
| Tampering | Audit log modification | No API endpoint updates/deletes `audit_logs` rows; DB-level `UPDATE`/`DELETE` grants should be revoked from the app's DB role in production | Not enforced at the DB permission level in the default docker-compose (the app user currently has full DDL/DML rights for migration convenience) — **harden before production**, see below |
| Repudiation | User denies an action | Every state-changing action writes an `audit_logs` row with actor, IP, timestamp, decision | Audit logs are not exported to a separate immutable store (e.g. WORM storage or a SIEM) by default |
| Information Disclosure | JWT payload contains roles/attributes | Tokens are signed (HS256) but not encrypted; do not put secrets in `attributes` | Consider RS256 + short-lived tokens (already 10 min) for production; avoid storing sensitive PII in the `attributes` JSON column |
| Information Disclosure | OIDC state stored in-process memory (`oidc.py: _pending_flows`) | Fine for a single-instance dev deployment | **Must** move to Redis (already provisioned) before running multiple backend replicas — otherwise a callback can land on a replica that never issued the `state` |
| Denial of Service | OPA unreachable | Backend fails closed (`deny`) rather than open | An attacker who can take down OPA causes a denial of service for legitimate users too — acceptable tradeoff for a Zero-Trust system (fail closed), but worth alerting on |
| Elevation of Privilege | Role/attribute tampering | Only `require_admin`-guarded endpoints can assign roles or edit attributes | Standard FastAPI dependency-injection guard; no additional layered check (e.g. a second-admin-approval workflow) is implemented |
| Elevation of Privilege | OPA policy bundle tampering | `opa/policy.rego` is mounted read-only into the OPA container | In production, policy changes should go through the same CI/CD review process as application code — this repo does not implement a policy approval workflow |

## Production hardening checklist (not fully implemented here)
- [ ] Put TLS termination in front of both frontend and backend (reverse proxy / ingress).
- [ ] Move OIDC PKCE state (`_pending_flows`) to Redis for multi-replica deployments.
- [ ] Add rate limiting / account lockout on `/auth/login` and `/auth/refresh`.
- [ ] Restrict the application's database role to exclude `UPDATE`/`DELETE` on `audit_logs`.
- [ ] Rotate `JWT_SIGNING_KEY` via a KMS/HSM-backed process instead of a static `.env` value; consider RS256.
- [ ] Configure a real EDR/MDM integration before treating any device as fully trusted
      (see `EDR_PROVIDER` / `EDR_API_KEY` / `EDR_API_BASE_URL` in `.env.example` — unset by
      default, and `device_service.fetch_verified_posture_from_edr` intentionally raises
      `NotImplementedError` rather than fabricate a vendor integration).
- [ ] Ship `audit_logs` to an external, append-only log sink (e.g. a SIEM) in addition to
      the local table.
- [ ] Add network policies/firewalling so Postgres, Redis, and OPA are never reachable
      outside the backend's own network segment.

## Explicitly out of scope
- Automated offensive security scanning of any kind (per the source requirements).
- Any credential harvesting, exfiltration tooling, or unrestricted network scanning.
- A real, vendor-specific EDR/MDM adapter (no credentials or vendor were specified).
