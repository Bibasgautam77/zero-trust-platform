const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export interface TokenResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
  step_up_required: boolean;
  risk_score: number;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(body.detail || `Request failed: ${res.status}`);
  }
  if (res.status === 204) return undefined as unknown as T;
  return res.json() as Promise<T>;
}

export function authHeader(token: string): HeadersInit {
  return { Authorization: `Bearer ${token}` };
}

export const api = {
  register: (email: string, full_name: string, password: string) =>
    request("/api/v1/auth/register", { method: "POST", body: JSON.stringify({ email, full_name, password }) }),

  login: (email: string, password: string, device_fingerprint: string, mfa_code?: string) =>
    request<TokenResponse>("/api/v1/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password, device_fingerprint, mfa_code }),
    }),

  refresh: (refresh_token: string, device_fingerprint: string) =>
    request<TokenResponse>("/api/v1/auth/refresh", {
      method: "POST",
      body: JSON.stringify({ refresh_token, device_fingerprint }),
    }),

  logout: (refresh_token: string, device_fingerprint: string) =>
    request<void>("/api/v1/auth/logout", {
      method: "POST",
      body: JSON.stringify({ refresh_token, device_fingerprint }),
    }),

  me: (token: string) => request("/api/v1/users/me", { headers: authHeader(token) }),

  enrollMfa: (token: string) =>
    request<{ secret: string; provisioning_uri: string }>("/api/v1/mfa/enroll", {
      method: "POST",
      headers: authHeader(token),
    }),

  verifyMfa: (token: string, code: string) =>
    request<void>("/api/v1/mfa/verify", {
      method: "POST",
      headers: authHeader(token),
      body: JSON.stringify({ code }),
    }),

  listDevices: (token: string) => request("/api/v1/devices", { headers: authHeader(token) }),

  registerDevice: (token: string, device: Record<string, unknown>) =>
    request("/api/v1/devices", { method: "POST", headers: authHeader(token), body: JSON.stringify(device) }),

  listSessions: (token: string) => request("/api/v1/sessions", { headers: authHeader(token) }),

  revokeSession: (token: string, sessionId: string) =>
    request<void>(`/api/v1/sessions/${sessionId}/revoke`, { method: "POST", headers: authHeader(token) }),

  checkPolicy: (token: string, resource: string, action: string) =>
    request("/api/v1/policy/check", {
      method: "POST",
      headers: authHeader(token),
      body: JSON.stringify({ resource, action }),
    }),

  listAuditLogs: (token: string) => request("/api/v1/audit", { headers: authHeader(token) }),
};

/** A simple, non-cryptographic device fingerprint from stable browser signals.
 * Sufficient to distinguish "this browser install" from another for device
 * registration purposes; NOT a security boundary on its own (see README's
 * threat-model notes on device identity). */
export function getDeviceFingerprint(): string {
  if (typeof window === "undefined") return "server";
  const key = "ztp_device_fingerprint";
  let fp = localStorage.getItem(key);
  if (!fp) {
    fp = `${navigator.userAgent}-${screen.width}x${screen.height}-${crypto.randomUUID()}`;
    localStorage.setItem(key, fp);
  }
  return fp;
}
