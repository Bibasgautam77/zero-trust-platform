"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, getDeviceFingerprint } from "@/lib/api";

export default function NavBar({ isAdmin }: { isAdmin?: boolean }) {
  const router = useRouter();

  async function handleLogout() {
    const refreshToken = localStorage.getItem("ztp_refresh_token");
    if (refreshToken) {
      try {
        await api.logout(refreshToken, getDeviceFingerprint());
      } catch {
        // best-effort; clear local state regardless
      }
    }
    localStorage.removeItem("ztp_access_token");
    localStorage.removeItem("ztp_refresh_token");
    router.push("/login");
  }

  return (
    <nav className="nav">
      <Link href="/dashboard">Dashboard</Link>
      <Link href="/devices">Devices</Link>
      <Link href="/sessions">Sessions</Link>
      {isAdmin && <Link href="/admin/audit">Audit Log</Link>}
      <span style={{ flex: 1 }} />
      <a onClick={handleLogout} style={{ cursor: "pointer" }}>
        Sign out
      </a>
    </nav>
  );
}
