"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, getDeviceFingerprint } from "@/lib/api";
import NavBar from "@/components/NavBar";

interface DeviceOut {
  id: string;
  device_name: string;
  device_fingerprint: string;
  disk_encrypted: boolean;
  screen_lock_enabled: boolean;
  edr_present: boolean;
  self_reported: boolean;
  posture_score: number;
  is_trusted: boolean;
}

export default function DevicesPage() {
  const router = useRouter();
  const [devices, setDevices] = useState<DeviceOut[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [deviceName, setDeviceName] = useState("My Device");
  const [diskEncrypted, setDiskEncrypted] = useState(true);
  const [screenLock, setScreenLock] = useState(true);
  const [edrPresent, setEdrPresent] = useState(false);

  function token() {
    const t = localStorage.getItem("ztp_access_token");
    if (!t) router.replace("/login");
    return t!;
  }

  async function loadDevices() {
    try {
      const result = await api.listDevices(token());
      setDevices(result as DeviceOut[]);
    } catch (err: any) {
      setError(err.message);
    }
  }

  useEffect(() => {
    loadDevices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await api.registerDevice(token(), {
        device_name: deviceName,
        device_fingerprint: getDeviceFingerprint(),
        disk_encrypted: diskEncrypted,
        screen_lock_enabled: screenLock,
        edr_present: edrPresent,
      });
      await loadDevices();
    } catch (err: any) {
      setError(err.message);
    }
  }

  return (
    <>
      <NavBar />
      <div className="wide-card">
        <h2>Registered devices</h2>
        <p style={{ color: "var(--muted)", fontSize: 13 }}>
          Posture fields below are self-reported by this browser unless a real EDR/MDM
          integration is configured server-side (EDR_PROVIDER / EDR_API_KEY /
          EDR_API_BASE_URL). Self-reported posture lowers - but never fully removes - risk.
        </p>
        <table>
          <thead>
            <tr>
              <th>Name</th><th>Posture score</th><th>Trusted</th><th>Source</th>
            </tr>
          </thead>
          <tbody>
            {devices.map((d) => (
              <tr key={d.id}>
                <td>{d.device_name}</td>
                <td>{d.posture_score}/100</td>
                <td>
                  <span className={`badge ${d.is_trusted ? "trusted" : "deny"}`}>
                    {d.is_trusted ? "trusted" : "untrusted"}
                  </span>
                </td>
                <td>{d.self_reported ? "self-reported" : "EDR-verified"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="wide-card">
        <h3>Register this device</h3>
        <form onSubmit={handleRegister}>
          <label>Device name</label>
          <input value={deviceName} onChange={(e) => setDeviceName(e.target.value)} />
          <label style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 12 }}>
            <input type="checkbox" style={{ width: "auto" }} checked={diskEncrypted} onChange={(e) => setDiskEncrypted(e.target.checked)} />
            Disk encryption enabled
          </label>
          <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <input type="checkbox" style={{ width: "auto" }} checked={screenLock} onChange={(e) => setScreenLock(e.target.checked)} />
            Screen lock enabled
          </label>
          <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <input type="checkbox" style={{ width: "auto" }} checked={edrPresent} onChange={(e) => setEdrPresent(e.target.checked)} />
            EDR / endpoint agent present
          </label>
          {error && <p className="error">{error}</p>}
          <button type="submit" style={{ marginTop: 12 }}>Register device</button>
        </form>
      </div>
    </>
  );
}
