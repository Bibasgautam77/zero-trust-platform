"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import NavBar from "@/components/NavBar";

interface SessionOut {
  id: string;
  ip_address: string | null;
  user_agent: string | null;
  risk_score_at_login: number;
  mfa_verified: boolean;
  is_revoked: boolean;
  created_at: string;
  expires_at: string;
}

export default function SessionsPage() {
  const router = useRouter();
  const [sessions, setSessions] = useState<SessionOut[]>([]);
  const [error, setError] = useState<string | null>(null);

  function token() {
    const t = localStorage.getItem("ztp_access_token");
    if (!t) router.replace("/login");
    return t!;
  }

  async function load() {
    try {
      setSessions((await api.listSessions(token())) as SessionOut[]);
    } catch (err: any) {
      setError(err.message);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function revoke(id: string) {
    try {
      await api.revokeSession(token(), id);
      await load();
    } catch (err: any) {
      setError(err.message);
    }
  }

  return (
    <>
      <NavBar />
      <div className="wide-card">
        <h2>Active sessions</h2>
        <p style={{ color: "var(--muted)", fontSize: 13 }}>
          Sessions are short-lived (access tokens expire in minutes) and every refresh
          re-evaluates risk. Revoking here immediately invalidates the session server-side.
        </p>
        {error && <p className="error">{error}</p>}
        <table>
          <thead>
            <tr><th>IP</th><th>Risk at login</th><th>MFA</th><th>Status</th><th>Expires</th><th></th></tr>
          </thead>
          <tbody>
            {sessions.map((s) => (
              <tr key={s.id}>
                <td>{s.ip_address || "unknown"}</td>
                <td>{s.risk_score_at_login}</td>
                <td>{s.mfa_verified ? "verified" : "no"}</td>
                <td>
                  <span className={`badge ${s.is_revoked ? "deny" : "allow"}`}>
                    {s.is_revoked ? "revoked" : "active"}
                  </span>
                </td>
                <td>{new Date(s.expires_at).toLocaleString()}</td>
                <td>
                  {!s.is_revoked && (
                    <button className="danger" onClick={() => revoke(s.id)}>Revoke</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
