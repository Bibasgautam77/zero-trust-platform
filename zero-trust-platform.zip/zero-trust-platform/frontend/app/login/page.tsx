"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, getDeviceFingerprint } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mfaCode, setMfaCode] = useState("");
  const [needsMfa, setNeedsMfa] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const fp = getDeviceFingerprint();
      const result = await api.login(email, password, fp, needsMfa ? mfaCode : undefined);
      localStorage.setItem("ztp_access_token", result.access_token);
      localStorage.setItem("ztp_refresh_token", result.refresh_token);
      localStorage.setItem("ztp_risk_score", String(result.risk_score));
      if (result.step_up_required) {
        router.push("/mfa-setup?stepup=1");
      } else {
        router.push("/dashboard");
      }
    } catch (err: any) {
      if (err.message?.toLowerCase().includes("mfa code required")) {
        setNeedsMfa(true);
        setError("Enter your 6-digit authenticator code.");
      } else {
        setError(err.message || "Login failed");
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card">
      <h2>Zero-Trust Access Platform</h2>
      <p style={{ color: "var(--muted)", fontSize: 13 }}>
        Identity + Device → Policy Engine → Decision → Least-Privilege Session → Continuous Audit
      </p>
      <form onSubmit={handleSubmit}>
        <label>Email</label>
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <label>Password</label>
        <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        {needsMfa && (
          <>
            <label>Authenticator Code</label>
            <input
              inputMode="numeric"
              maxLength={6}
              value={mfaCode}
              onChange={(e) => setMfaCode(e.target.value)}
            />
          </>
        )}
        {error && <p className="error">{error}</p>}
        <button type="submit" disabled={loading}>{loading ? "Verifying…" : "Sign in"}</button>
      </form>
      <button
        className="secondary"
        style={{ marginTop: 12 }}
        onClick={() => router.push("/register")}
      >
        Create an account
      </button>
      <p style={{ fontSize: 12, color: "var(--muted)", marginTop: 16 }}>
        Demo bootstrap admin credentials are printed to the backend logs the first time
        <code> python -m scripts.seed_data </code> runs. Rotate them immediately.
      </p>
    </div>
  );
}
