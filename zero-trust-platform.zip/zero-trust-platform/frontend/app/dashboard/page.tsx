"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import NavBar from "@/components/NavBar";

interface Me {
  email: string;
  full_name: string;
  is_admin: boolean;
  mfa_enabled: boolean;
  roles: string[];
  attributes: Record<string, unknown>;
}

export default function DashboardPage() {
  const router = useRouter();
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [checkResult, setCheckResult] = useState<any>(null);
  const [resource, setResource] = useState("employee-portal");
  const [action, setAction] = useState("read");

  useEffect(() => {
    const token = localStorage.getItem("ztp_access_token");
    if (!token) {
      router.replace("/login");
      return;
    }
    api
      .me(token)
      .then((res: any) => setMe(res))
      .catch((err) => setError(err.message));
  }, [router]);

  async function runPolicyCheck() {
    const token = localStorage.getItem("ztp_access_token");
    if (!token) return;
    try {
      const result = await api.checkPolicy(token, resource, action);
      setCheckResult(result);
    } catch (err: any) {
      setError(err.message);
    }
  }

  if (!me) return <div className="card"><p>{error || "Loading…"}</p></div>;

  const riskScore = Number(localStorage.getItem("ztp_risk_score") || 0);

  return (
    <>
      <NavBar isAdmin={me.is_admin} />
      <div className="wide-card">
        <h2>Welcome, {me.full_name}</h2>
        <p style={{ color: "var(--muted)" }}>{me.email}</p>
        <p>
          Roles: {me.roles.length ? me.roles.join(", ") : "none assigned"} &nbsp;|&nbsp; MFA:{" "}
          {me.mfa_enabled ? "enabled" : "disabled"} &nbsp;|&nbsp; Session risk score: {riskScore}
        </p>
        {!me.mfa_enabled && (
          <p className="error">
            MFA is not enabled on this account. <a href="/mfa-setup" style={{ color: "var(--accent)" }}>Enable it now</a>.
          </p>
        )}
      </div>

      <div className="wide-card">
        <h3>Continuous verification: policy check</h3>
        <p style={{ color: "var(--muted)", fontSize: 13 }}>
          Every sensitive action should call the policy engine before proceeding - not just at
          login. Try it here against the OPA-backed RBAC/ABAC + risk gate.
        </p>
        <label>Resource</label>
        <input value={resource} onChange={(e) => setResource(e.target.value)} />
        <label>Action</label>
        <input value={action} onChange={(e) => setAction(e.target.value)} />
        <button onClick={runPolicyCheck} style={{ marginTop: 12 }}>Check access</button>
        {checkResult && (
          <div style={{ marginTop: 16 }}>
            <span className={`badge ${checkResult.decision}`}>{checkResult.decision.toUpperCase()}</span>
            <p style={{ fontSize: 13, color: "var(--muted)" }}>Risk score: {checkResult.risk_score}</p>
            <ul style={{ fontSize: 13, color: "var(--muted)" }}>
              {checkResult.reasons.map((r: string, i: number) => (
                <li key={i}>{r}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </>
  );
}
