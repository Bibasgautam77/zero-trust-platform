import "./globals.css";
import type { ReactNode } from "react";

export const metadata = {
  title: "Zero-Trust Access Platform",
  description: "Identity + Device -> Policy Engine -> Decision -> Least-Privilege Session -> Continuous Audit",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="app-shell">{children}</div>
      </body>
    </html>
  );
}
