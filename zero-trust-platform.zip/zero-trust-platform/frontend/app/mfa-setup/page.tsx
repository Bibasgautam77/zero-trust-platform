"use client";
import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { QRCodeSVG } from "qrcode.react";
import { api } from "@/lib/api";

export default function MfaSetupPage() {
  const router = useRouter();
  const params = useSearchParams();
  const stepUp = params.get("stepup") === "1";

  const [secret, setSecret] = useState("");
  const [uri, setUri] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("ztp_access_token");
    if (!token) {
      router.replace("/login");
      return;
    }
    api
      .enrollMfa(token)
      .then((res: any) => {
        setSecret(res.secret);
        setUri(res.provisioning_uri);
      })
      .catch((err) => setError(err.message));
  }, [router]);

  async function handleVerify(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const token = localStorage.getItem("ztp_access_token");
    if (!token) return;
    try {
      await api.verifyMfa(token, code);
      setDone(true);
      setTimeout(() => router.push("/dashboard"), 1200);
    } catch (err: any) {
      setError(err.message || "Invalid code");
    }
  }

  return (
    <div className="card">
      <h2>{stepUp ? "Step-up verification required" : "Set up multi-factor authentication"}</h2>
      <p style={{ color: "var(--muted)", fontSize: 13 }}>
        Your current session risk score is elevated. Scan this QR code (or enter the secret
        manually) into an authenticator app such as Google Authenticator or 1Password, then
        confirm with a generated code.
      </p>
      {uri && (
        <div style={{ background: "white", padding: 12, borderRadius: 8, margin: "16px 0", textAlign: "center" }}>
          {/* Rendered entirely client-side (qrcode.react) - the TOTP secret/URI is
              never sent to any third-party service, only encoded locally in the browser. */}
          <QRCodeSVG value={uri} size={200} />
        </div>
      )}
      <p style={{ fontSize: 12, wordBreak: "break-all", color: "var(--muted)" }}>Secret: {secret}</p>
      <form onSubmit={handleVerify}>
        <label>Enter 6-digit code</label>
        <input inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} />
        {error && <p className="error">{error}</p>}
        {done && <p style={{ color: "var(--success)", fontSize: 13 }}>MFA enabled. Redirecting…</p>}
        <button type="submit">Confirm</button>
      </form>
    </div>
  );
}
