"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import NavBar from "@/components/NavBar";

interface AuditLogOut {
  id: string;
  timestamp: string;
  actor_email: string | null;
  action: string;
  resource: string | null;
  decision: string | null;
  risk_score: number | null;
  ip_address: string | null;
}

export default function AuditLogPage() {
  const router = useRouter();
  const [logs, setLogs] = useState<AuditLogOut[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem("ztp_access_token");
    if (!token) {
      router.replace("/login");
      return;
    }
    api
      .listAuditLogs(token)
      .then((res) => setLogs(res as AuditLogOut[]))
      .catch((err) => setError(err.message || "Failed to load audit log (admin only)"));
  }, [router]);

  return (
    <>
      <NavBar isAdmin />
      <div className="wide-card">
        <h2>Audit log</h2>
        <p style={{ color: "var(--muted)", fontSize: 13 }}>
          Append-only. Every login, policy decision, device change, and admin action is recorded
          here and mirrored to structured stdout logs for SIEM ingestion.
        </p>
        {error && <p className="error">{error}</p>}
        <table>
          <thead>
            <tr><th>Time</th><th>Actor</th><th>Action</th><th>Resource</th><th>Decision</th><th>Risk</th><th>IP</th></tr>
          </thead>
          <tbody>
            {logs.map((l) => (
              <tr key={l.id}>
                <td>{new Date(l.timestamp).toLocaleString()}</td>
                <td>{l.actor_email || "-"}</td>
                <td>{l.action}</td>
                <td>{l.resource || "-"}</td>
                <td>{l.decision ? <span className={`badge ${l.decision}`}>{l.decision}</span> : "-"}</td>
                <td>{l.risk_score ?? "-"}</td>
                <td>{l.ip_address || "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
