"use client";
import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { getDeviceFingerprint } from "@/lib/api";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export default function OidcCallbackPage() {
  const router = useRouter();
  const params = useSearchParams();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const code = params.get("code");
    const state = params.get("state");
    if (!code || !state) {
      setError("Missing OIDC callback parameters");
      return;
    }

    fetch(`${API_BASE}/api/v1/oidc/callback`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, state, device_fingerprint: getDeviceFingerprint() }),
    })
      .then(async (res) => {
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          throw new Error(body.detail || "OIDC login failed");
        }
        return res.json();
      })
      .then((data) => {
        localStorage.setItem("ztp_access_token", data.access_token);
        localStorage.setItem("ztp_refresh_token", data.refresh_token);
        localStorage.setItem("ztp_risk_score", String(data.risk_score));
        router.push(data.step_up_required ? "/mfa-setup?stepup=1" : "/dashboard");
      })
      .catch((err) => setError(err.message));
  }, [params, router]);

  return (
    <div className="card">
      <h2>Completing sign-in…</h2>
      {error && <p className="error">{error}</p>}
    </div>
  );
}
