# Zero-Trust Access Platform - Policy Decision Point
#
# Combines:
#   - RBAC: role -> resource/action permission table
#   - ABAC: attribute conditions (e.g. department must match resource owner)
#   - Continuous risk gating: high risk score overrides an otherwise-allowed
#     RBAC/ABAC decision (defense in depth with the app's own risk engine)
#
# Input shape (see backend/app/services/policy_engine.py):
# {
#   "subject": {"roles": ["admin"], "attributes": {"department": "finance"}},
#   "resource": "finance-reports",
#   "action": "read",
#   "risk_score": 12,
#   "device_trusted": true,
#   "mfa_verified": true
# }

package ztp.authz

import future.keywords.in
import future.keywords.if

default decision := {"allow": false, "reasons": ["no matching policy rule"]}

# ---------------------------------------------------------------------------
# RBAC permission table: role -> [ {resource, action} ]
# In production this table would be loaded from the policy_bundles table via
# CI/CD rather than hard-coded, but is kept explicit here for auditability.
# ---------------------------------------------------------------------------
role_permissions := {
	"admin": [{"resource": "*", "action": "*"}],
	"auditor": [
		{"resource": "audit-logs", "action": "read"},
		{"resource": "*", "action": "read"},
	],
	"employee": [
		{"resource": "employee-portal", "action": "read"},
		{"resource": "employee-portal", "action": "write"},
	],
	"finance": [
		{"resource": "finance-reports", "action": "read"},
		{"resource": "finance-reports", "action": "write"},
	],
}

rbac_allow if {
	some role in input.subject.roles
	perms := role_permissions[role]
	some perm in perms
	resource_matches(perm.resource)
	action_matches(perm.action)
}

resource_matches(p) if p == "*"
resource_matches(p) if p == input.resource

action_matches(p) if p == "*"
action_matches(p) if p == input.action

# ---------------------------------------------------------------------------
# ABAC: department-scoped resources require attribute match.
# Example: resource "finance-reports" additionally requires the subject's
# `department` attribute to be "finance" or the subject to hold the admin role.
# ---------------------------------------------------------------------------
abac_allow if {
	input.resource != "finance-reports"
}

abac_allow if {
	input.resource == "finance-reports"
	input.subject.attributes.department == "finance"
}

abac_allow if {
	input.resource == "finance-reports"
	"admin" in input.subject.roles
}

# ---------------------------------------------------------------------------
# Risk gate: regardless of RBAC/ABAC, deny outright above the hard risk
# ceiling, and require MFA + a trusted device for anything but the lowest
# risk tier. These thresholds mirror (and double-check) the app-level
# risk_engine.py thresholds - defense in depth between PDP and app logic.
# ---------------------------------------------------------------------------
risk_gate_allow if {
	input.risk_score < 60
	input.mfa_verified == true
}

risk_gate_allow if {
	input.risk_score < 30
}

final_allow if {
	rbac_allow
	abac_allow
	risk_gate_allow
	input.risk_score < 85
}

reasons contains "role/action permission denied" if not rbac_allow
reasons contains "attribute-based condition not met" if not abac_allow
reasons contains "risk score too high or MFA/device requirement unmet" if not risk_gate_allow
reasons contains "risk score at or above hard deny ceiling (85)" if input.risk_score >= 85

decision := {"allow": final_allow, "reasons": [r | some r in reasons]} if {
	final_allow
} else := {"allow": false, "reasons": [r | some r in reasons]}
