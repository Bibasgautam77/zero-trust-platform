package ztp.authz

import future.keywords.in

test_admin_allowed_everything if {
	decision.allow with input as {
		"subject": {"roles": ["admin"], "attributes": {}},
		"resource": "finance-reports",
		"action": "write",
		"risk_score": 10,
		"device_trusted": true,
		"mfa_verified": true,
	}
}

test_employee_denied_finance_reports if {
	not decision.allow with input as {
		"subject": {"roles": ["employee"], "attributes": {"department": "engineering"}},
		"resource": "finance-reports",
		"action": "read",
		"risk_score": 10,
		"device_trusted": true,
		"mfa_verified": true,
	}
}

test_finance_role_allowed_finance_reports_with_matching_department if {
	decision.allow with input as {
		"subject": {"roles": ["finance"], "attributes": {"department": "finance"}},
		"resource": "finance-reports",
		"action": "read",
		"risk_score": 15,
		"device_trusted": true,
		"mfa_verified": true,
	}
}

test_finance_role_denied_without_matching_department if {
	not decision.allow with input as {
		"subject": {"roles": ["finance"], "attributes": {"department": "sales"}},
		"resource": "finance-reports",
		"action": "read",
		"risk_score": 15,
		"device_trusted": true,
		"mfa_verified": true,
	}
}

test_high_risk_denies_even_admin if {
	not decision.allow with input as {
		"subject": {"roles": ["admin"], "attributes": {}},
		"resource": "finance-reports",
		"action": "read",
		"risk_score": 90,
		"device_trusted": false,
		"mfa_verified": false,
	}
}

test_moderate_risk_without_mfa_denied if {
	not decision.allow with input as {
		"subject": {"roles": ["employee"], "attributes": {}},
		"resource": "employee-portal",
		"action": "read",
		"risk_score": 45,
		"device_trusted": true,
		"mfa_verified": false,
	}
}

test_low_risk_without_mfa_allowed if {
	decision.allow with input as {
		"subject": {"roles": ["employee"], "attributes": {}},
		"resource": "employee-portal",
		"action": "read",
		"risk_score": 20,
		"device_trusted": true,
		"mfa_verified": false,
	}
}
