import time

import pyotp
import pytest

from app.core import security


def test_password_hash_and_verify_roundtrip():
    hashed = security.hash_password("a-strong-password-123")
    assert security.verify_password("a-strong-password-123", hashed)
    assert not security.verify_password("wrong-password", hashed)


def test_access_token_roundtrip():
    token = security.create_access_token(
        subject="user-123",
        session_id="session-456",
        roles=["employee"],
        attributes={"department": "engineering"},
        risk_score=15,
    )
    payload = security.decode_token(token)
    assert payload["sub"] == "user-123"
    assert payload["sid"] == "session-456"
    assert payload["roles"] == ["employee"]
    assert payload["risk"] == 15
    assert payload["token_type"] == "access"


def test_expired_token_raises():
    from datetime import timedelta

    token = security.create_access_token(
        subject="user-123",
        session_id="session-456",
        roles=[],
        attributes={},
        risk_score=0,
        expires_delta=timedelta(seconds=-1),
    )
    with pytest.raises(ValueError):
        security.decode_token(token)


def test_totp_enrollment_and_verification():
    secret = security.generate_mfa_secret()
    uri = security.get_totp_provisioning_uri(secret, "user@example.com")
    assert "otpauth://totp/" in uri

    valid_code = pyotp.TOTP(secret).now()
    assert security.verify_totp_code(secret, valid_code)
    assert not security.verify_totp_code(secret, "000000")
