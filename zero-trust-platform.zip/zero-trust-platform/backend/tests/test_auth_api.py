import pyotp
import pytest


@pytest.mark.asyncio
async def test_register_and_login_flow(client):
    register_resp = await client.post(
        "/api/v1/auth/register",
        json={"email": "alice@example.com", "full_name": "Alice", "password": "correct-horse-battery-staple"},
    )
    assert register_resp.status_code == 201

    login_resp = await client.post(
        "/api/v1/auth/login",
        json={
            "email": "alice@example.com",
            "password": "correct-horse-battery-staple",
            "device_fingerprint": "device-abc",
        },
    )
    assert login_resp.status_code == 200
    body = login_resp.json()
    assert "access_token" in body
    assert "refresh_token" in body
    # No device registered + no MFA => risk should push this to step_up, not a flat allow
    assert body["step_up_required"] is True


@pytest.mark.asyncio
async def test_login_wrong_password_fails(client):
    await client.post(
        "/api/v1/auth/register",
        json={"email": "bob@example.com", "full_name": "Bob", "password": "correct-horse-battery-staple"},
    )
    resp = await client.post(
        "/api/v1/auth/login",
        json={"email": "bob@example.com", "password": "wrong-password", "device_fingerprint": "d1"},
    )
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_mfa_enrollment_flow(client):
    await client.post(
        "/api/v1/auth/register",
        json={"email": "carol@example.com", "full_name": "Carol", "password": "correct-horse-battery-staple"},
    )
    login_resp = await client.post(
        "/api/v1/auth/login",
        json={"email": "carol@example.com", "password": "correct-horse-battery-staple", "device_fingerprint": "d1"},
    )
    access_token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {access_token}"}

    enroll_resp = await client.post("/api/v1/mfa/enroll", headers=headers)
    assert enroll_resp.status_code == 200
    secret = enroll_resp.json()["secret"]

    code = pyotp.TOTP(secret).now()
    verify_resp = await client.post("/api/v1/mfa/verify", headers=headers, json={"code": code})
    assert verify_resp.status_code == 204

    me_resp = await client.get("/api/v1/users/me", headers=headers)
    assert me_resp.json()["mfa_enabled"] is True


@pytest.mark.asyncio
async def test_device_registration_lowers_risk(client):
    await client.post(
        "/api/v1/auth/register",
        json={"email": "dave@example.com", "full_name": "Dave", "password": "correct-horse-battery-staple"},
    )
    login_resp = await client.post(
        "/api/v1/auth/login",
        json={"email": "dave@example.com", "password": "correct-horse-battery-staple", "device_fingerprint": "trusted-device-1"},
    )
    access_token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {access_token}"}

    device_resp = await client.post(
        "/api/v1/devices",
        headers=headers,
        json={
            "device_name": "Work Laptop",
            "device_fingerprint": "trusted-device-1",
            "disk_encrypted": True,
            "screen_lock_enabled": True,
            "edr_present": True,
        },
    )
    assert device_resp.status_code == 201
    assert device_resp.json()["posture_score"] == 100

    # Second login with the now-registered device should carry a lower risk score.
    login_resp2 = await client.post(
        "/api/v1/auth/login",
        json={"email": "dave@example.com", "password": "correct-horse-battery-staple", "device_fingerprint": "trusted-device-1"},
    )
    assert login_resp2.json()["risk_score"] < login_resp.json()["risk_score"]


@pytest.mark.asyncio
async def test_session_list_and_revoke(client):
    await client.post(
        "/api/v1/auth/register",
        json={"email": "erin@example.com", "full_name": "Erin", "password": "correct-horse-battery-staple"},
    )
    login_resp = await client.post(
        "/api/v1/auth/login",
        json={"email": "erin@example.com", "password": "correct-horse-battery-staple", "device_fingerprint": "d1"},
    )
    access_token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {access_token}"}

    sessions_resp = await client.get("/api/v1/sessions", headers=headers)
    assert sessions_resp.status_code == 200
    sessions = sessions_resp.json()
    assert len(sessions) == 1

    revoke_resp = await client.post(f"/api/v1/sessions/{sessions[0]['id']}/revoke", headers=headers)
    assert revoke_resp.status_code == 204

    # Using the now-revoked session's access token should be rejected.
    me_resp = await client.get("/api/v1/users/me", headers=headers)
    assert me_resp.status_code == 401
