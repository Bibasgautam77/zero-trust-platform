from app.models.models import Device, User
from app.services.risk_engine import RiskContext, compute_risk_score, decision_from_score


def make_user() -> User:
    return User(email="u@example.com", full_name="U", hashed_password="x")


def make_trusted_device() -> Device:
    return Device(
        owner_id="owner",
        device_name="laptop",
        device_fingerprint="fp-1",
        disk_encrypted=True,
        screen_lock_enabled=True,
        edr_present=True,
        self_reported=False,
        is_trusted=True,
        posture_score=100,
    )


def test_full_trust_low_risk():
    ctx = RiskContext(user=make_user(), device=make_trusted_device(), mfa_verified=True, ip_address="10.0.0.5")
    result = compute_risk_score(ctx)
    assert result.score < 30
    assert decision_from_score(result.score, 30, 60, 85) == "allow"


def test_no_device_no_mfa_is_high_risk():
    ctx = RiskContext(user=make_user(), device=None, mfa_verified=False, ip_address=None)
    result = compute_risk_score(ctx)
    assert result.score >= 60
    assert decision_from_score(result.score, 30, 60, 85) in ("step_up", "deny")
    assert "MFA not verified for this session" in result.reasons
    assert "No registered device presented" in result.reasons


def test_untrusted_ip_adds_risk():
    ctx_known = RiskContext(
        user=make_user(), device=make_trusted_device(), mfa_verified=True,
        ip_address="10.0.0.5", known_ip_prefixes=["10.0.0."],
    )
    ctx_unknown = RiskContext(
        user=make_user(), device=make_trusted_device(), mfa_verified=True,
        ip_address="203.0.113.9", known_ip_prefixes=["10.0.0."],
    )
    assert compute_risk_score(ctx_unknown).score > compute_risk_score(ctx_known).score


def test_score_never_exceeds_100():
    ctx = RiskContext(
        user=make_user(), device=Device(
            owner_id="o", device_name="d", device_fingerprint="fp",
            disk_encrypted=False, screen_lock_enabled=False, edr_present=False,
            self_reported=True, is_trusted=False,
        ),
        mfa_verified=False,
        ip_address="1.2.3.4",
        known_ip_prefixes=["10.0.0."],
    )
    result = compute_risk_score(ctx)
    assert 0 <= result.score <= 100


def test_decision_thresholds():
    assert decision_from_score(10, 30, 60, 85) == "allow"
    assert decision_from_score(45, 30, 60, 85) == "step_up"
    assert decision_from_score(90, 30, 60, 85) == "deny"
