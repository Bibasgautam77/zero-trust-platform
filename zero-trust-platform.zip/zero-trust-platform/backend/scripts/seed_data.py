"""
Idempotent seed script: creates default roles and a bootstrap admin user.

Usage (from backend/ inside the container or a local venv with DATABASE_URL set):
    python -m scripts.seed_data

The bootstrap admin password is printed once to stdout and must be rotated
immediately after first login. It is never written to disk or logged again.
"""
import asyncio
import secrets

from sqlalchemy import select

from app.core.database import AsyncSessionLocal, init_models
from app.core.security import hash_password
from app.models.models import Role, User

DEFAULT_ROLES = [
    ("admin", "Full administrative access to the platform"),
    ("auditor", "Read-only access to all resources and audit logs"),
    ("employee", "Standard employee access to the employee portal"),
    ("finance", "Access to finance department resources"),
]


async def seed() -> None:
    await init_models()
    async with AsyncSessionLocal() as db:
        for name, description in DEFAULT_ROLES:
            existing = await db.execute(select(Role).where(Role.name == name))
            if not existing.scalar_one_or_none():
                db.add(Role(name=name, description=description))
        await db.commit()

        admin_email = "admin@example.com"
        existing_admin = await db.execute(select(User).where(User.email == admin_email))
        admin_user = existing_admin.scalar_one_or_none()
        if not admin_user:
            bootstrap_password = secrets.token_urlsafe(16)
            admin_role_result = await db.execute(select(Role).where(Role.name == "admin"))
            admin_role = admin_role_result.scalar_one()

            admin_user = User(
                email=admin_email,
                full_name="Platform Administrator",
                hashed_password=hash_password(bootstrap_password),
                is_admin=True,
                is_active=True,
            )
            admin_user.roles.append(admin_role)
            db.add(admin_user)
            await db.commit()

            print("=" * 70)
            print("Bootstrap admin account created:")
            print(f"  email:    {admin_email}")
            print(f"  password: {bootstrap_password}")
            print("ROTATE THIS PASSWORD IMMEDIATELY AFTER FIRST LOGIN.")
            print("=" * 70)
        else:
            print("Admin user already exists; skipping bootstrap credential creation.")


if __name__ == "__main__":
    asyncio.run(seed())
