from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, EmailStr, Field


# ---------------- Auth ----------------
class RegisterRequest(BaseModel):
    email: EmailStr
    full_name: str
    password: str = Field(min_length=10)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str
    device_fingerprint: str
    mfa_code: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    step_up_required: bool = False
    risk_score: int


class RefreshRequest(BaseModel):
    refresh_token: str
    device_fingerprint: str


# ---------------- MFA ----------------
class MfaEnrollResponse(BaseModel):
    secret: str
    provisioning_uri: str


class MfaVerifyRequest(BaseModel):
    code: str


# ---------------- Users ----------------
class UserOut(BaseModel):
    id: str
    email: str
    full_name: str
    is_active: bool
    is_admin: bool
    mfa_enabled: bool
    roles: list[str]
    attributes: dict[str, Any]

    model_config = {"from_attributes": True}


class UserAttributeUpdate(BaseModel):
    attributes: dict[str, Any]


class RoleAssignRequest(BaseModel):
    role_names: list[str]


# ---------------- Devices ----------------
class DeviceRegisterRequest(BaseModel):
    device_name: str
    device_fingerprint: str
    os_name: Optional[str] = None
    os_version: Optional[str] = None
    disk_encrypted: bool = False
    screen_lock_enabled: bool = False
    edr_present: bool = False


class DeviceOut(BaseModel):
    id: str
    device_name: str
    device_fingerprint: str
    os_name: Optional[str]
    os_version: Optional[str]
    disk_encrypted: bool
    screen_lock_enabled: bool
    edr_present: bool
    self_reported: bool
    posture_score: int
    is_trusted: bool
    last_seen_at: Optional[datetime]

    model_config = {"from_attributes": True}


# ---------------- Sessions ----------------
class SessionOut(BaseModel):
    id: str
    device_id: Optional[str]
    ip_address: Optional[str]
    user_agent: Optional[str]
    risk_score_at_login: int
    mfa_verified: bool
    is_revoked: bool
    created_at: datetime
    expires_at: datetime
    last_verified_at: datetime

    model_config = {"from_attributes": True}


# ---------------- Policy ----------------
class PolicyCheckRequest(BaseModel):
    resource: str
    action: str


class PolicyCheckResponse(BaseModel):
    decision: str  # allow | deny | step_up
    risk_score: int
    reasons: list[str]


# ---------------- Audit ----------------
class AuditLogOut(BaseModel):
    id: str
    timestamp: datetime
    actor_email: Optional[str]
    action: str
    resource: Optional[str]
    decision: Optional[str]
    risk_score: Optional[int]
    ip_address: Optional[str]
    details: dict[str, Any]

    model_config = {"from_attributes": True}
