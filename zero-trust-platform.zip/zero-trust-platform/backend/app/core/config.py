"""
Centralized application configuration.

All values are loaded from environment variables (see .env.example).
No secrets are hard-coded here. Defaults exist only for local/dev ergonomics
and are intentionally insecure placeholders that must be overridden in any
non-development environment.
"""
from functools import lru_cache
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    environment: str = "development"
    log_level: str = "INFO"

    # Database
    database_url: str = "postgresql+asyncpg://ztp_user:changeme_dev_only@postgres:5432/ztp_db"

    # Redis
    redis_url: str = "redis://redis:6379/0"

    # OPA
    opa_url: str = "http://opa:8181"

    # OIDC
    oidc_issuer: str = "http://localhost:8080/realms/zero-trust"
    oidc_client_id: str = "ztp-backend"
    oidc_client_secret: str = "changeme_generate_a_real_secret"
    oidc_redirect_uri: str = "http://localhost:3000/auth/callback"

    # JWT / sessions
    jwt_signing_key: str = "changeme_replace_with_openssl_rand_hex_32"
    jwt_algorithm: str = "HS256"
    access_token_ttl_seconds: int = 600
    refresh_token_ttl_seconds: int = 86400
    continuous_verification_interval_seconds: int = 120

    # MFA
    mfa_issuer_name: str = "ZeroTrustPlatform"
    mfa_totp_window: int = 1

    # Risk engine
    risk_threshold_allow: int = 30
    risk_threshold_step_up: int = 60
    risk_threshold_deny: int = 85

    # Optional external integrations (disabled unless configured)
    edr_provider: str = ""
    edr_api_key: str = ""
    edr_api_base_url: str = ""
    mdm_provider: str = ""
    mdm_api_key: str = ""

    # CORS
    backend_cors_origins: str = "http://localhost:3000"

    @property
    def cors_origins_list(self) -> List[str]:
        return [o.strip() for o in self.backend_cors_origins.split(",") if o.strip()]

    @property
    def edr_integration_enabled(self) -> bool:
        return bool(self.edr_provider and self.edr_api_key and self.edr_api_base_url)


@lru_cache
def get_settings() -> Settings:
    return Settings()
