"""
Security primitives: password hashing, short-lived JWT session tokens,
and TOTP-based MFA. Kept isolated so it can be audited/replaced independently
(e.g. swapping HS256 for RS256 backed by an HSM/KMS in production).
"""
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import pyotp
from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import get_settings

settings = get_settings()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ---------------------------------------------------------------------------
# Password hashing
# ---------------------------------------------------------------------------
def hash_password(plain_password: str) -> str:
    return pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


# ---------------------------------------------------------------------------
# JWT session tokens (short-lived, per Zero-Trust "least privilege session")
# ---------------------------------------------------------------------------
def create_access_token(
    subject: str,
    session_id: str,
    roles: list[str],
    attributes: dict[str, Any],
    risk_score: int,
    expires_delta: Optional[timedelta] = None,
) -> str:
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(seconds=settings.access_token_ttl_seconds)
    )
    payload = {
        "sub": subject,
        "sid": session_id,
        "roles": roles,
        "attrs": attributes,
        "risk": risk_score,
        "iat": datetime.now(timezone.utc),
        "exp": expire,
        "jti": str(uuid.uuid4()),
        "token_type": "access",
    }
    return jwt.encode(payload, settings.jwt_signing_key, algorithm=settings.jwt_algorithm)


def create_refresh_token(subject: str, session_id: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(
        seconds=settings.refresh_token_ttl_seconds
    )
    payload = {
        "sub": subject,
        "sid": session_id,
        "iat": datetime.now(timezone.utc),
        "exp": expire,
        "jti": str(uuid.uuid4()),
        "token_type": "refresh",
    }
    return jwt.encode(payload, settings.jwt_signing_key, algorithm=settings.jwt_algorithm)


def decode_token(token: str) -> dict[str, Any]:
    try:
        return jwt.decode(token, settings.jwt_signing_key, algorithms=[settings.jwt_algorithm])
    except JWTError as exc:
        raise ValueError(f"Invalid or expired token: {exc}") from exc


# ---------------------------------------------------------------------------
# TOTP MFA (RFC 6238)
# ---------------------------------------------------------------------------
def generate_mfa_secret() -> str:
    return pyotp.random_base32()


def get_totp_provisioning_uri(secret: str, account_email: str) -> str:
    totp = pyotp.TOTP(secret)
    return totp.provisioning_uri(name=account_email, issuer_name=settings.mfa_issuer_name)


def verify_totp_code(secret: str, code: str) -> bool:
    totp = pyotp.TOTP(secret)
    return totp.verify(code, valid_window=settings.mfa_totp_window)
