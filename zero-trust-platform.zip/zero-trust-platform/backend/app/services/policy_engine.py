"""
Client for Open Policy Agent (OPA). We POST a structured input document
(subject roles/attributes, resource, action, risk score, device posture) to
OPA's REST API and get back a decision. The actual RBAC/ABAC rules live in
/opa/policy.rego (Rego), kept out of application code so policy can be
changed/audited/versioned independently of the app (a core Zero-Trust tenet:
policy decision point separated from policy enforcement point).
"""
from typing import Any

import httpx

from app.core.config import get_settings
from app.core.logging_config import get_logger

settings = get_settings()
logger = get_logger(__name__)

OPA_DECISION_PATH = "/v1/data/ztp/authz/decision"


async def evaluate_policy(
    roles: list[str],
    attributes: dict[str, Any],
    resource: str,
    action: str,
    risk_score: int,
    device_trusted: bool,
    mfa_verified: bool,
) -> dict[str, Any]:
    """Returns OPA's decision document, e.g. {"allow": bool, "reasons": [...]}"""
    input_doc = {
        "input": {
            "subject": {"roles": roles, "attributes": attributes},
            "resource": resource,
            "action": action,
            "risk_score": risk_score,
            "device_trusted": device_trusted,
            "mfa_verified": mfa_verified,
        }
    }
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            resp = await client.post(f"{settings.opa_url}{OPA_DECISION_PATH}", json=input_doc)
            resp.raise_for_status()
            data = resp.json()
            return data.get("result", {"allow": False, "reasons": ["OPA returned no result"]})
    except httpx.HTTPError as exc:
        # Fail closed: if the policy engine is unreachable, deny by default.
        logger.error("opa_unreachable", error=str(exc))
        return {"allow": False, "reasons": [f"Policy engine unreachable, failing closed: {exc}"]}
