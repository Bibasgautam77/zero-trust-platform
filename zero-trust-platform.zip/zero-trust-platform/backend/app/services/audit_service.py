"""
Append-only audit trail writer. Every authentication event, policy decision,
device change, and admin action is recorded here. No code path in this
application updates or deletes AuditLog rows.
"""
from typing import Any, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging_config import get_logger
from app.models.models import AuditLog

logger = get_logger("audit")


async def record_audit_event(
    db: AsyncSession,
    action: str,
    actor_user_id: Optional[str] = None,
    actor_email: Optional[str] = None,
    resource: Optional[str] = None,
    decision: Optional[str] = None,
    risk_score: Optional[int] = None,
    ip_address: Optional[str] = None,
    details: Optional[dict[str, Any]] = None,
) -> AuditLog:
    entry = AuditLog(
        actor_user_id=actor_user_id,
        actor_email=actor_email,
        action=action,
        resource=resource,
        decision=decision,
        risk_score=risk_score,
        ip_address=ip_address,
        details=details or {},
    )
    db.add(entry)
    await db.commit()
    await db.refresh(entry)

    # Mirror to structured stdout logs for shipping to a SIEM.
    logger.info(
        "audit_event",
        action=action,
        actor_email=actor_email,
        resource=resource,
        decision=decision,
        risk_score=risk_score,
        ip_address=ip_address,
    )
    return entry
