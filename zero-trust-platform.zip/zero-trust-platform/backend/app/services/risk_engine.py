"""
Risk-based access: computes a 0-100 risk score from signals available at
request time. Higher = riskier. This score is fed into the OPA policy
decision (policy_engine.py) and re-computed on every continuous-verification
check, not just at login.

This is a transparent, rule-based scorer (not ML) by design: every score is
explainable, which matters for an auditable Zero-Trust control.
"""
from dataclasses import dataclass, field
from datetime import datetime, timezone

from app.models.models import Device, User


@dataclass
class RiskContext:
    user: User
    device: Device | None
    mfa_verified: bool
    ip_address: str | None
    known_ip_prefixes: list[str] = field(default_factory=list)
    request_hour_utc: int = field(default_factory=lambda: datetime.now(timezone.utc).hour)


@dataclass
class RiskResult:
    score: int
    reasons: list[str]


def compute_risk_score(ctx: RiskContext) -> RiskResult:
    score = 0
    reasons: list[str] = []

    # --- Authentication strength ---
    if not ctx.mfa_verified:
        score += 35
        reasons.append("MFA not verified for this session")

    # --- Device posture ---
    if ctx.device is None:
        score += 30
        reasons.append("No registered device presented")
    else:
        if not ctx.device.disk_encrypted:
            score += 15
            reasons.append("Device disk is not encrypted")
        if not ctx.device.screen_lock_enabled:
            score += 10
            reasons.append("Device screen lock is not enabled")
        if not ctx.device.edr_present:
            score += 10
            reasons.append("No EDR/endpoint agent reported on device")
        if ctx.device.self_reported:
            score += 5
            reasons.append("Device posture is self-reported (no verified EDR/MDM integration configured)")
        if not ctx.device.is_trusted:
            score += 10
            reasons.append("Device has not been marked as trusted")

    # --- Network / geo anomaly (simplified: prefix allow-list) ---
    if ctx.ip_address and ctx.known_ip_prefixes:
        if not any(ctx.ip_address.startswith(p) for p in ctx.known_ip_prefixes):
            score += 15
            reasons.append("Source IP address is outside known network ranges")

    # --- Time-of-day anomaly (very simple heuristic: 00:00-05:00 UTC riskier) ---
    if 0 <= ctx.request_hour_utc < 5:
        score += 5
        reasons.append("Access occurring during an unusual hour (00:00-05:00 UTC)")

    return RiskResult(score=min(score, 100), reasons=reasons)


def decision_from_score(score: int, allow_th: int, step_up_th: int, deny_th: int) -> str:
    """allow_th/step_up_th/deny_th are ascending risk thresholds (0-100).
    score < allow_th          -> allow
    allow_th <= score < deny_th -> step_up (additional verification required)
    score >= deny_th          -> deny
    (step_up_th is exposed separately for UI messaging: below it a step-up is
    "recommended", at/above it it is "required".)"""
    if score >= deny_th:
        return "deny"
    if score >= allow_th:
        return "step_up"
    return "allow"
