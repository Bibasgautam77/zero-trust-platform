"""
OIDC/OAuth2 client using the Authorization Code + PKCE flow, against
whatever OIDC-compliant IdP is configured via OIDC_ISSUER (Keycloak ships in
docker-compose as a working local demo IdP; point this at your real
enterprise IdP - Okta, Azure AD/Entra ID, Auth0, etc. - in production by
changing only the env vars, no code changes required).
"""
import base64
import hashlib
import secrets
from typing import Any

import httpx

from app.core.config import get_settings
from app.core.logging_config import get_logger

settings = get_settings()
logger = get_logger(__name__)

_discovery_cache: dict[str, Any] = {}


async def get_discovery_document() -> dict[str, Any]:
    if _discovery_cache:
        return _discovery_cache
    url = f"{settings.oidc_issuer}/.well-known/openid-configuration"
    async with httpx.AsyncClient(timeout=5.0) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        _discovery_cache.update(resp.json())
    return _discovery_cache


def generate_pkce_pair() -> tuple[str, str]:
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(64)).rstrip(b"=").decode()
    challenge = (
        base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    )
    return verifier, challenge


def build_authorization_url(state: str, code_challenge: str) -> str:
    from urllib.parse import urlencode

    params = {
        "client_id": settings.oidc_client_id,
        "response_type": "code",
        "redirect_uri": settings.oidc_redirect_uri,
        "scope": "openid profile email",
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
    }
    return f"{settings.oidc_issuer}/protocol/openid-connect/auth?{urlencode(params)}"


async def exchange_code_for_tokens(code: str, code_verifier: str) -> dict[str, Any]:
    discovery = await get_discovery_document()
    token_endpoint = discovery.get(
        "token_endpoint", f"{settings.oidc_issuer}/protocol/openid-connect/token"
    )
    data = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": settings.oidc_redirect_uri,
        "client_id": settings.oidc_client_id,
        "client_secret": settings.oidc_client_secret,
        "code_verifier": code_verifier,
    }
    async with httpx.AsyncClient(timeout=5.0) as client:
        resp = await client.post(token_endpoint, data=data)
        resp.raise_for_status()
        return resp.json()


async def get_userinfo(access_token: str) -> dict[str, Any]:
    discovery = await get_discovery_document()
    userinfo_endpoint = discovery.get(
        "userinfo_endpoint", f"{settings.oidc_issuer}/protocol/openid-connect/userinfo"
    )
    async with httpx.AsyncClient(timeout=5.0) as client:
        resp = await client.get(
            userinfo_endpoint, headers={"Authorization": f"Bearer {access_token}"}
        )
        resp.raise_for_status()
        return resp.json()
