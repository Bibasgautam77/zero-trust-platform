"""
Device posture scoring. Computes a 0-100 posture score from self-reported
(or, when EDR_PROVIDER/EDR_API_KEY/EDR_API_BASE_URL are configured, verified)
signals. See app/core/config.py: Settings.edr_integration_enabled.

IMPORTANT: without a configured EDR/MDM integration, all posture data is
self-reported by the client and MUST be treated as advisory only, never as
strong assurance. This module makes that explicit via the `self_reported`
flag stored on every Device row.
"""
from app.core.config import get_settings

settings = get_settings()


def score_device_posture(
    disk_encrypted: bool,
    screen_lock_enabled: bool,
    edr_present: bool,
) -> tuple[int, bool]:
    """Returns (posture_score 0-100, is_trusted)."""
    score = 0
    if disk_encrypted:
        score += 35
    if screen_lock_enabled:
        score += 25
    if edr_present:
        score += 40

    # A device can only be fully "trusted" if posture is strong AND the data
    # was independently verified via a real EDR/MDM integration.
    is_trusted = score >= 80 and settings.edr_integration_enabled
    return score, is_trusted


async def fetch_verified_posture_from_edr(device_fingerprint: str) -> dict | None:
    """Placeholder integration point for a real EDR/MDM provider
    (e.g. CrowdStrike Falcon, Microsoft Intune, Jamf). Returns None and is a
    no-op unless EDR_PROVIDER/EDR_API_KEY/EDR_API_BASE_URL are set in the
    environment. This function intentionally does NOT fabricate data -
    it must not be extended to return synthetic results as if they were
    verified.
    """
    if not settings.edr_integration_enabled:
        return None

    # Real implementation would call settings.edr_api_base_url here using
    # settings.edr_api_key, mapped per settings.edr_provider's API shape.
    # Left unimplemented: no credentials/spec were provided for a specific
    # vendor. Document required env vars in README instead of guessing an API.
    raise NotImplementedError(
        f"EDR provider '{settings.edr_provider}' is configured but no vendor "
        "adapter is implemented. Add one in device_service.py following your "
        "vendor's API docs before enabling this in production."
    )
