from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.routes import audit, auth, devices, mfa, oidc, policy, sessions, users
from app.core.config import get_settings
from app.core.database import init_models
from app.core.logging_config import configure_logging, get_logger

settings = get_settings()
configure_logging()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("startup", environment=settings.environment)
    if settings.environment == "development":
        # Convenience for local/dev only. Production uses Alembic migrations
        # (see db/migrations and README "Database Migrations").
        await init_models()
    yield
    logger.info("shutdown")


app = FastAPI(
    title="Enterprise Zero-Trust Access Platform",
    description=(
        "Reference implementation: OIDC/OAuth2, MFA, RBAC/ABAC via OPA, "
        "device posture, risk-based access, short-lived sessions, continuous audit."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.error("unhandled_exception", path=str(request.url), error=str(exc))
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "Internal server error"},
    )


@app.get("/health", tags=["health"])
async def health():
    return {"status": "ok", "environment": settings.environment}


app.include_router(auth.router, prefix="/api/v1")
app.include_router(oidc.router, prefix="/api/v1")
app.include_router(mfa.router, prefix="/api/v1")
app.include_router(devices.router, prefix="/api/v1")
app.include_router(sessions.router, prefix="/api/v1")
app.include_router(policy.router, prefix="/api/v1")
app.include_router(audit.router, prefix="/api/v1")
app.include_router(users.router, prefix="/api/v1")
