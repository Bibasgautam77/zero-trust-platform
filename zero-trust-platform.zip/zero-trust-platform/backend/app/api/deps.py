from typing import Optional

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import decode_token
from app.models.models import Session as SessionModel
from app.models.models import User

bearer_scheme = HTTPBearer(auto_error=True)


class CurrentSession:
    def __init__(self, user: User, session: SessionModel, token_payload: dict):
        self.user = user
        self.session = session
        self.token_payload = token_payload


async def get_current_session(
    request: Request,
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> CurrentSession:
    try:
        payload = decode_token(credentials.credentials)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc

    if payload.get("token_type") != "access":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Wrong token type")

    session_id = payload.get("sid")
    result = await db.execute(select(SessionModel).where(SessionModel.id == session_id))
    session_row = result.scalar_one_or_none()
    if session_row is None or session_row.is_revoked:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Session revoked or not found")

    user_result = await db.execute(select(User).where(User.id == payload.get("sub")))
    user = user_result.scalar_one_or_none()
    if user is None or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User inactive or not found")

    request.state.current_ip = request.client.host if request.client else None
    return CurrentSession(user=user, session=session_row, token_payload=payload)


async def require_admin(current: CurrentSession = Depends(get_current_session)) -> CurrentSession:
    if not current.user.is_admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin privileges required")
    return current
