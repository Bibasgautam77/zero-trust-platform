import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db
from app.core.security import create_access_token, create_refresh_token, decode_token
from app.models.models import Session as SessionModel, User
from app.schemas.schemas import TokenResponse
from app.services.audit_service import record_audit_event
from app.services.oidc_service import (
    build_authorization_url,
    exchange_code_for_tokens,
    generate_pkce_pair,
    get_userinfo,
)

router = APIRouter(prefix="/oidc", tags=["oidc"])
settings = get_settings()

# In production, PKCE verifier/state should be stored server-side keyed by
# a short-lived cookie or in Redis, not in-process memory (which won't work
# across multiple backend replicas). This in-memory store is a documented
# limitation for the local/dev demo; see README "Known Limitations".
_pending_flows: dict[str, str] = {}


class AuthorizeUrlResponse(BaseModel):
    authorization_url: str
    state: str


class OidcCallbackRequest(BaseModel):
    code: str
    state: str
    device_fingerprint: str


@router.get("/authorize-url", response_model=AuthorizeUrlResponse)
async def get_authorize_url():
    state = secrets.token_urlsafe(24)
    verifier, challenge = generate_pkce_pair()
    _pending_flows[state] = verifier
    url = build_authorization_url(state, challenge)
    return AuthorizeUrlResponse(authorization_url=url, state=state)


@router.post("/callback", response_model=TokenResponse)
async def oidc_callback(payload: OidcCallbackRequest, db: AsyncSession = Depends(get_db)):
    verifier = _pending_flows.pop(payload.state, None)
    if not verifier:
        raise HTTPException(status_code=400, detail="Unknown or expired OIDC state")

    try:
        tokens = await exchange_code_for_tokens(payload.code, verifier)
        userinfo = await get_userinfo(tokens["access_token"])
    except Exception as exc:  # noqa: BLE001 - surfaced as a clean 502 to the client
        raise HTTPException(status_code=502, detail=f"OIDC provider error: {exc}") from exc

    subject = userinfo["sub"]
    email = userinfo.get("email")
    full_name = userinfo.get("name", email or subject)

    result = await db.execute(select(User).where(User.oidc_subject == subject))
    user = result.scalar_one_or_none()
    if user is None and email:
        # Link by email if a local account already exists.
        result = await db.execute(select(User).where(User.email == email))
        user = result.scalar_one_or_none()

    if user is None:
        user = User(
            email=email or f"{subject}@oidc.local",
            full_name=full_name,
            hashed_password="",  # OIDC-only account; local password login is disabled
            oidc_subject=subject,
        )
        db.add(user)
    else:
        user.oidc_subject = subject

    await db.commit()
    await db.refresh(user)

    session_id = str(uuid.uuid4())
    refresh_token = create_refresh_token(subject=user.id, session_id=session_id)
    refresh_payload = decode_token(refresh_token)

    session_row = SessionModel(
        id=session_id,
        user_id=user.id,
        refresh_token_jti=refresh_payload["jti"],
        mfa_verified=False,
        risk_score_at_login=40,  # OIDC login without local device/MFA context yet
        expires_at=datetime.now(timezone.utc) + timedelta(seconds=settings.refresh_token_ttl_seconds),
    )
    db.add(session_row)
    await db.commit()

    roles = [r.name for r in user.roles]
    access_token = create_access_token(
        subject=user.id, session_id=session_id, roles=roles, attributes=user.attributes, risk_score=40
    )

    await record_audit_event(
        db, action="oidc_login_succeeded", actor_user_id=user.id, actor_email=user.email,
    )

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.access_token_ttl_seconds,
        step_up_required=True,  # always require device+MFA step-up after first OIDC login
        risk_score=40,
    )
