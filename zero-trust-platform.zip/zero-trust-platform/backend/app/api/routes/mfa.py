from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import CurrentSession, get_current_session
from app.core.database import get_db
from app.core.security import generate_mfa_secret, get_totp_provisioning_uri, verify_totp_code
from app.schemas.schemas import MfaEnrollResponse, MfaVerifyRequest
from app.services.audit_service import record_audit_event

router = APIRouter(prefix="/mfa", tags=["mfa"])


@router.post("/enroll", response_model=MfaEnrollResponse)
async def enroll_mfa(current: CurrentSession = Depends(get_current_session), db: AsyncSession = Depends(get_db)):
    user = current.user
    if user.mfa_enabled:
        raise HTTPException(status_code=400, detail="MFA already enabled")

    secret = generate_mfa_secret()
    user.mfa_secret = secret  # not yet enabled until verified
    await db.commit()

    uri = get_totp_provisioning_uri(secret, user.email)
    return MfaEnrollResponse(secret=secret, provisioning_uri=uri)


@router.post("/verify", status_code=204)
async def verify_mfa_enrollment(
    payload: MfaVerifyRequest,
    current: CurrentSession = Depends(get_current_session),
    db: AsyncSession = Depends(get_db),
):
    user = current.user
    if not user.mfa_secret:
        raise HTTPException(status_code=400, detail="MFA enrollment not started")

    if not verify_totp_code(user.mfa_secret, payload.code):
        raise HTTPException(status_code=400, detail="Invalid MFA code")

    user.mfa_enabled = True
    await db.commit()
    await record_audit_event(db, action="mfa_enabled", actor_user_id=user.id, actor_email=user.email)


@router.post("/disable", status_code=204)
async def disable_mfa(
    payload: MfaVerifyRequest,
    current: CurrentSession = Depends(get_current_session),
    db: AsyncSession = Depends(get_db),
):
    user = current.user
    if not user.mfa_enabled:
        raise HTTPException(status_code=400, detail="MFA not enabled")
    if not verify_totp_code(user.mfa_secret, payload.code):
        raise HTTPException(status_code=400, detail="Invalid MFA code")

    user.mfa_enabled = False
    user.mfa_secret = None
    await db.commit()
    await record_audit_event(db, action="mfa_disabled", actor_user_id=user.id, actor_email=user.email)
