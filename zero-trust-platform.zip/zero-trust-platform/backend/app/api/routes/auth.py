import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
    verify_totp_code,
)
from app.models.models import Device, Session as SessionModel, User
from app.schemas.schemas import LoginRequest, RefreshRequest, RegisterRequest, TokenResponse
from app.services.audit_service import record_audit_event
from app.services.risk_engine import RiskContext, compute_risk_score, decision_from_score

router = APIRouter(prefix="/auth", tags=["auth"])
settings = get_settings()


@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(select(User).where(User.email == payload.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email already registered")

    user = User(
        email=payload.email,
        full_name=payload.full_name,
        hashed_password=hash_password(payload.password),
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)

    await record_audit_event(db, action="user_registered", actor_user_id=user.id, actor_email=user.email)
    return {"id": user.id, "email": user.email}


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest, request: Request, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.email == payload.email))
    user = result.scalar_one_or_none()

    ip_address = request.client.host if request.client else None

    if user is None or not verify_password(payload.password, user.hashed_password):
        await record_audit_event(
            db, action="login_failed", actor_email=payload.email, ip_address=ip_address,
            details={"reason": "invalid_credentials"},
        )
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Account disabled")

    mfa_verified = False
    if user.mfa_enabled:
        if not payload.mfa_code:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="MFA code required",
            )
        if not verify_totp_code(user.mfa_secret, payload.mfa_code):
            await record_audit_event(
                db, action="login_failed", actor_user_id=user.id, actor_email=user.email,
                ip_address=ip_address, details={"reason": "invalid_mfa_code"},
            )
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid MFA code")
        mfa_verified = True

    device_result = await db.execute(
        select(Device).where(Device.device_fingerprint == payload.device_fingerprint, Device.owner_id == user.id)
    )
    device = device_result.scalar_one_or_none()

    risk_result = compute_risk_score(
        RiskContext(user=user, device=device, mfa_verified=mfa_verified, ip_address=ip_address)
    )
    decision = decision_from_score(
        risk_result.score,
        settings.risk_threshold_allow,
        settings.risk_threshold_step_up,
        settings.risk_threshold_deny,
    )

    if decision == "deny":
        await record_audit_event(
            db, action="login_denied", actor_user_id=user.id, actor_email=user.email,
            ip_address=ip_address, decision="deny", risk_score=risk_result.score,
            details={"reasons": risk_result.reasons},
        )
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied by risk policy")

    step_up_required = decision == "step_up" and not mfa_verified

    session_id = str(uuid.uuid4())
    refresh_token = create_refresh_token(subject=user.id, session_id=session_id)
    refresh_payload = decode_token(refresh_token)

    session_row = SessionModel(
        id=session_id,
        user_id=user.id,
        device_id=device.id if device else None,
        refresh_token_jti=refresh_payload["jti"],
        ip_address=ip_address,
        user_agent=request.headers.get("user-agent"),
        risk_score_at_login=risk_result.score,
        mfa_verified=mfa_verified,
        expires_at=datetime.now(timezone.utc) + timedelta(seconds=settings.refresh_token_ttl_seconds),
    )
    db.add(session_row)
    await db.commit()

    roles = [r.name for r in user.roles]
    access_token = create_access_token(
        subject=user.id,
        session_id=session_id,
        roles=roles,
        attributes=user.attributes,
        risk_score=risk_result.score,
    )

    await record_audit_event(
        db, action="login_succeeded", actor_user_id=user.id, actor_email=user.email,
        ip_address=ip_address, decision=decision, risk_score=risk_result.score,
        details={"reasons": risk_result.reasons, "step_up_required": step_up_required},
    )

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.access_token_ttl_seconds,
        step_up_required=step_up_required,
        risk_score=risk_result.score,
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh(payload: RefreshRequest, db: AsyncSession = Depends(get_db)):
    try:
        token_payload = decode_token(payload.refresh_token)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc

    if token_payload.get("token_type") != "refresh":
        raise HTTPException(status_code=401, detail="Wrong token type")

    session_result = await db.execute(
        select(SessionModel).where(SessionModel.id == token_payload["sid"])
    )
    session_row = session_result.scalar_one_or_none()
    if (
        session_row is None
        or session_row.is_revoked
        or session_row.refresh_token_jti != token_payload["jti"]
    ):
        raise HTTPException(status_code=401, detail="Session revoked or refresh token reused")

    user_result = await db.execute(select(User).where(User.id == session_row.user_id))
    user = user_result.scalar_one_or_none()
    if user is None or not user.is_active:
        raise HTTPException(status_code=401, detail="User inactive or not found")

    device_result = await db.execute(
        select(Device).where(Device.device_fingerprint == payload.device_fingerprint, Device.owner_id == user.id)
    )
    device = device_result.scalar_one_or_none()

    # Continuous verification: recompute risk on every refresh, not just login.
    risk_result = compute_risk_score(
        RiskContext(user=user, device=device, mfa_verified=session_row.mfa_verified, ip_address=session_row.ip_address)
    )
    decision = decision_from_score(
        risk_result.score, settings.risk_threshold_allow, settings.risk_threshold_step_up, settings.risk_threshold_deny
    )
    if decision == "deny":
        session_row.is_revoked = True
        session_row.revoked_reason = "risk_score_exceeded_on_refresh"
        await db.commit()
        await record_audit_event(
            db, action="session_revoked", actor_user_id=user.id, actor_email=user.email,
            decision="deny", risk_score=risk_result.score, details={"reasons": risk_result.reasons},
        )
        raise HTTPException(status_code=403, detail="Session revoked: risk policy re-evaluation failed")

    # Rotate refresh token (mitigate replay).
    new_session_id_marker = session_row.id  # session identity stays; jti rotates
    new_refresh_token = create_refresh_token(subject=user.id, session_id=session_row.id)
    new_refresh_payload = decode_token(new_refresh_token)
    session_row.refresh_token_jti = new_refresh_payload["jti"]
    session_row.last_verified_at = datetime.now(timezone.utc)
    session_row.risk_score_at_login = risk_result.score
    await db.commit()

    roles = [r.name for r in user.roles]
    access_token = create_access_token(
        subject=user.id, session_id=session_row.id, roles=roles,
        attributes=user.attributes, risk_score=risk_result.score,
    )

    await record_audit_event(
        db, action="token_refreshed", actor_user_id=user.id, actor_email=user.email,
        decision=decision, risk_score=risk_result.score,
    )

    return TokenResponse(
        access_token=access_token,
        refresh_token=new_refresh_token,
        expires_in=settings.access_token_ttl_seconds,
        step_up_required=(decision == "step_up"),
        risk_score=risk_result.score,
    )


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(payload: RefreshRequest, db: AsyncSession = Depends(get_db)):
    try:
        token_payload = decode_token(payload.refresh_token)
    except ValueError:
        return  # already invalid; nothing to revoke

    result = await db.execute(select(SessionModel).where(SessionModel.id == token_payload.get("sid")))
    session_row = result.scalar_one_or_none()
    if session_row:
        session_row.is_revoked = True
        session_row.revoked_reason = "user_logout"
        await db.commit()
        await record_audit_event(db, action="logout", actor_user_id=session_row.user_id)
