from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import CurrentSession, get_current_session
from app.core.database import get_db
from app.models.models import Session as SessionModel
from app.schemas.schemas import SessionOut
from app.services.audit_service import record_audit_event

router = APIRouter(prefix="/sessions", tags=["sessions"])


@router.get("", response_model=list[SessionOut])
async def list_my_sessions(
    current: CurrentSession = Depends(get_current_session), db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(SessionModel).where(SessionModel.user_id == current.user.id))
    return result.scalars().all()


@router.post("/{session_id}/revoke", status_code=204)
async def revoke_session(
    session_id: str,
    current: CurrentSession = Depends(get_current_session),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(SessionModel).where(SessionModel.id == session_id, SessionModel.user_id == current.user.id)
    )
    session_row = result.scalar_one_or_none()
    if not session_row:
        raise HTTPException(status_code=404, detail="Session not found")

    session_row.is_revoked = True
    session_row.revoked_reason = "user_initiated_revoke"
    await db.commit()
    await record_audit_event(
        db, action="session_revoked", actor_user_id=current.user.id, resource=session_id,
        details={"reason": "user_initiated_revoke"},
    )
