from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import CurrentSession, get_current_session, require_admin
from app.core.database import get_db
from app.models.models import Role, User
from app.schemas.schemas import RoleAssignRequest, UserAttributeUpdate, UserOut
from app.services.audit_service import record_audit_event

router = APIRouter(prefix="/users", tags=["users"])


def _to_user_out(user: User) -> UserOut:
    return UserOut(
        id=user.id,
        email=user.email,
        full_name=user.full_name,
        is_active=user.is_active,
        is_admin=user.is_admin,
        mfa_enabled=user.mfa_enabled,
        roles=[r.name for r in user.roles],
        attributes=user.attributes,
    )


@router.get("/me", response_model=UserOut)
async def get_me(current: CurrentSession = Depends(get_current_session)):
    return _to_user_out(current.user)


@router.get("", response_model=list[UserOut])
async def list_users(current: CurrentSession = Depends(require_admin), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User))
    return [_to_user_out(u) for u in result.scalars().unique().all()]


@router.patch("/{user_id}/attributes", response_model=UserOut)
async def update_attributes(
    user_id: str,
    payload: UserAttributeUpdate,
    current: CurrentSession = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.attributes = {**user.attributes, **payload.attributes}
    await db.commit()
    await db.refresh(user)

    await record_audit_event(
        db, action="user_attributes_updated", actor_user_id=current.user.id,
        resource=user_id, details={"attributes": payload.attributes},
    )
    return _to_user_out(user)


@router.post("/{user_id}/roles", response_model=UserOut)
async def assign_roles(
    user_id: str,
    payload: RoleAssignRequest,
    current: CurrentSession = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    roles_result = await db.execute(select(Role).where(Role.name.in_(payload.role_names)))
    roles = roles_result.scalars().all()
    found_names = {r.name for r in roles}
    missing = set(payload.role_names) - found_names
    if missing:
        raise HTTPException(status_code=400, detail=f"Unknown roles: {sorted(missing)}")

    user.roles = roles
    await db.commit()
    await db.refresh(user)

    await record_audit_event(
        db, action="user_roles_assigned", actor_user_id=current.user.id,
        resource=user_id, details={"roles": payload.role_names},
    )
    return _to_user_out(user)


@router.post("/{user_id}/disable", status_code=204)
async def disable_user(
    user_id: str, current: CurrentSession = Depends(require_admin), db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_active = False
    await db.commit()
    await record_audit_event(db, action="user_disabled", actor_user_id=current.user.id, resource=user_id)
