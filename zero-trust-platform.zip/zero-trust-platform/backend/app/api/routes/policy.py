from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import CurrentSession, get_current_session
from app.core.database import get_db
from app.models.models import Device
from app.schemas.schemas import PolicyCheckRequest, PolicyCheckResponse
from app.services.audit_service import record_audit_event
from app.services.policy_engine import evaluate_policy
from app.services.risk_engine import RiskContext, compute_risk_score

router = APIRouter(prefix="/policy", tags=["policy"])


@router.post("/check", response_model=PolicyCheckResponse)
async def check_policy(
    payload: PolicyCheckRequest,
    request: Request,
    current: CurrentSession = Depends(get_current_session),
    db: AsyncSession = Depends(get_db),
):
    """
    Continuous verification endpoint: any sensitive frontend action or
    downstream microservice can call this before performing `action` on
    `resource`. This is the Policy Decision Point (PDP) - OPA - fronted by
    the app's own risk re-scoring, per the Identity+Device -> Policy Engine
    -> Decision -> Least-Privilege Session -> Continuous Audit architecture.
    """
    device = None
    if current.session.device_id:
        result = await db.execute(select(Device).where(Device.id == current.session.device_id))
        device = result.scalar_one_or_none()

    ip_address = request.client.host if request.client else None
    risk_result = compute_risk_score(
        RiskContext(
            user=current.user,
            device=device,
            mfa_verified=current.session.mfa_verified,
            ip_address=ip_address,
        )
    )

    roles = [r.name for r in current.user.roles]
    opa_result = await evaluate_policy(
        roles=roles,
        attributes=current.user.attributes,
        resource=payload.resource,
        action=payload.action,
        risk_score=risk_result.score,
        device_trusted=device.is_trusted if device else False,
        mfa_verified=current.session.mfa_verified,
    )

    decision = "allow" if opa_result.get("allow") else "deny"
    reasons = opa_result.get("reasons", []) + risk_result.reasons

    await record_audit_event(
        db,
        action="policy_check",
        actor_user_id=current.user.id,
        actor_email=current.user.email,
        resource=payload.resource,
        decision=decision,
        risk_score=risk_result.score,
        ip_address=ip_address,
        details={"action": payload.action, "reasons": reasons},
    )

    return PolicyCheckResponse(decision=decision, risk_score=risk_result.score, reasons=reasons)
