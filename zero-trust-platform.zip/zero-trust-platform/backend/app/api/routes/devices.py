from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import CurrentSession, get_current_session
from app.core.database import get_db
from app.models.models import Device
from app.schemas.schemas import DeviceOut, DeviceRegisterRequest
from app.services.audit_service import record_audit_event
from app.services.device_service import score_device_posture

router = APIRouter(prefix="/devices", tags=["devices"])


@router.post("", response_model=DeviceOut, status_code=201)
async def register_device(
    payload: DeviceRegisterRequest,
    current: CurrentSession = Depends(get_current_session),
    db: AsyncSession = Depends(get_db),
):
    existing = await db.execute(
        select(Device).where(Device.device_fingerprint == payload.device_fingerprint)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Device already registered")

    score, is_trusted = score_device_posture(
        payload.disk_encrypted, payload.screen_lock_enabled, payload.edr_present
    )

    device = Device(
        owner_id=current.user.id,
        device_name=payload.device_name,
        device_fingerprint=payload.device_fingerprint,
        os_name=payload.os_name,
        os_version=payload.os_version,
        disk_encrypted=payload.disk_encrypted,
        screen_lock_enabled=payload.screen_lock_enabled,
        edr_present=payload.edr_present,
        self_reported=True,
        posture_score=score,
        is_trusted=is_trusted,
        last_seen_at=datetime.now(timezone.utc),
    )
    db.add(device)
    await db.commit()
    await db.refresh(device)

    await record_audit_event(
        db, action="device_registered", actor_user_id=current.user.id, actor_email=current.user.email,
        resource=device.id, details={"posture_score": score, "is_trusted": is_trusted},
    )
    return device


@router.get("", response_model=list[DeviceOut])
async def list_my_devices(
    current: CurrentSession = Depends(get_current_session), db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(Device).where(Device.owner_id == current.user.id))
    return result.scalars().all()


@router.post("/{device_id}/refresh-posture", response_model=DeviceOut)
async def refresh_posture(
    device_id: str,
    payload: DeviceRegisterRequest,
    current: CurrentSession = Depends(get_current_session),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Device).where(Device.id == device_id, Device.owner_id == current.user.id)
    )
    device = result.scalar_one_or_none()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    score, is_trusted = score_device_posture(
        payload.disk_encrypted, payload.screen_lock_enabled, payload.edr_present
    )
    device.disk_encrypted = payload.disk_encrypted
    device.screen_lock_enabled = payload.screen_lock_enabled
    device.edr_present = payload.edr_present
    device.posture_score = score
    device.is_trusted = is_trusted
    device.last_seen_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(device)

    await record_audit_event(
        db, action="device_posture_refreshed", actor_user_id=current.user.id,
        resource=device.id, details={"posture_score": score, "is_trusted": is_trusted},
    )
    return device


@router.delete("/{device_id}", status_code=204)
async def deregister_device(
    device_id: str,
    current: CurrentSession = Depends(get_current_session),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Device).where(Device.id == device_id, Device.owner_id == current.user.id)
    )
    device = result.scalar_one_or_none()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    await db.delete(device)
    await db.commit()
    await record_audit_event(db, action="device_deregistered", actor_user_id=current.user.id, resource=device_id)
