@echo off
REM ============================================================
REM Enterprise Zero-Trust Access Platform - Health Check Script
REM ============================================================
cd /d "%~dp0.."
echo === Health Check ===

echo.
echo -- Container status --
docker compose ps

echo.
echo -- Backend health endpoint --
curl -s http://localhost:8000/health
echo.

echo.
echo -- OPA health endpoint --
curl -s http://localhost:8181/health
echo.

echo.
echo -- Postgres readiness --
docker compose exec -T postgres pg_isready -U ztp_user

echo.
echo -- Redis ping --
docker compose exec -T redis redis-cli ping

echo.
echo === Health check complete ===
