@echo off
REM ============================================================
REM Enterprise Zero-Trust Access Platform - Stop Script (Windows)
REM ============================================================
cd /d "%~dp0.."
echo === Stopping Zero-Trust Access Platform ===
docker compose stop
if %errorlevel% neq 0 (
    echo ERROR: docker compose stop failed.
    exit /b 1
)
echo All services stopped. Data volumes are preserved.
echo Use "docker compose down -v" manually if you want to wipe all data.
