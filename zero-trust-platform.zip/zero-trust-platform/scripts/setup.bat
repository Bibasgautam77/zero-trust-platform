@echo off
REM ============================================================
REM Enterprise Zero-Trust Access Platform - Setup Script (Windows)
REM ============================================================
setlocal enabledelayedexpansion
cd /d "%~dp0.."

echo === Zero-Trust Access Platform: Setup ===

where docker >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: Docker is not installed or not on PATH. Install Docker Desktop first.
    exit /b 1
)

docker compose version >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: Docker Compose v2 is required. Update Docker Desktop.
    exit /b 1
)

if not exist ".env" (
    echo Creating .env from .env.example ...
    copy .env.example .env >nul
    echo IMPORTANT: edit .env and replace all "changeme_*" placeholders before production use.
) else (
    echo .env already exists, leaving it untouched.
)

echo Building images (this may take a few minutes on first run)...
docker compose build
if %errorlevel% neq 0 (
    echo ERROR: docker compose build failed. See output above.
    exit /b 1
)

echo Starting infrastructure services (postgres, redis, opa, keycloak)...
docker compose up -d postgres redis opa keycloak
if %errorlevel% neq 0 (
    echo ERROR: failed to start infrastructure services.
    exit /b 1
)

echo Waiting for Postgres to become healthy...
:waitloop
for /f "tokens=*" %%i in ('docker inspect -f "{{.State.Health.Status}}" ztp_postgres 2^>nul') do set PGSTATUS=%%i
if "!PGSTATUS!"=="healthy" goto ready
timeout /t 2 >nul
goto waitloop
:ready

echo Seeding default roles and bootstrap admin account...
docker compose run --rm backend python -m scripts.seed_data

echo.
echo === Setup complete ===
echo Run start.bat to bring up the full platform (backend + frontend).
endlocal
