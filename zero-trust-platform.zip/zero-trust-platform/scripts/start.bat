@echo off
REM ============================================================
REM Enterprise Zero-Trust Access Platform - Start Script (Windows)
REM ============================================================
cd /d "%~dp0.."
echo === Starting Zero-Trust Access Platform ===

if not exist ".env" (
    echo ERROR: .env not found. Run setup.bat first.
    exit /b 1
)

docker compose up -d
if %errorlevel% neq 0 (
    echo ERROR: docker compose up failed. See output above.
    exit /b 1
)

echo.
echo Services starting. Waiting for backend health check...
set /a attempts=0
:waitloop
set /a attempts+=1
curl -s -o nul -w "%%{http_code}" http://localhost:8000/health > "%TEMP%\ztp_health.txt" 2>nul
set /p HEALTHCODE=<"%TEMP%\ztp_health.txt"
if "%HEALTHCODE%"=="200" goto ready
if %attempts% GEQ 30 (
    echo WARNING: backend did not become healthy within expected time. Check "docker compose logs backend".
    goto done
)
timeout /t 2 >nul
goto waitloop

:ready
echo Backend is healthy.

:done
echo.
echo === Zero-Trust Access Platform is running ===
echo Frontend:  http://localhost:3000
echo Backend:   http://localhost:8000/docs
echo Keycloak:  http://localhost:8080  (admin console)
echo OPA:       http://localhost:8181
echo.
echo Use stop.bat to stop, or restart.bat to restart.
