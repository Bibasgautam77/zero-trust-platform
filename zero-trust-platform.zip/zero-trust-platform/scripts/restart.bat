@echo off
REM ============================================================
REM Enterprise Zero-Trust Access Platform - Restart Script (Windows)
REM ============================================================
echo === Restarting Zero-Trust Access Platform ===
call "%~dp0stop.bat"
call "%~dp0start.bat"
